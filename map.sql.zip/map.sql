-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 20, 2013 at 12:39 PM
-- Server version: 5.5.28
-- PHP Version: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `map`
--

CREATE TABLE IF NOT EXISTS `map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(100) NOT NULL,
  `college` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `map`
--

INSERT INTO `map` (`id`, `city`, `college`) VALUES
(1, 'Trichy', 'M.A.M. College of Engineering'),
(2, 'Trichy', 'JJ College of Engineering'),
(3, 'Trichy', 'TRP Engg Coll (SRM, Trichy Campus)'),
(4, 'Trichy', 'MIET'),
(5, 'Trichy', 'Trichy Engineering College'),
(6, 'Trichy', 'Moogambigai College'),
(7, 'Trichy', 'Saranathan College of Engg'),
(8, 'Trichy', 'Oxford Engineering College'),
(9, 'Trichy', 'CARE School of Engineering'),
(10, 'Trichy', 'Shivani Institute of Technology'),
(11, 'Trichy', 'PABCET'),
(12, 'Trichy', 'Indra Ganesan College of Engineering'),
(13, 'Trichy', 'Jayaram College of Engineering and technology'),
(14, 'Trichy', 'Kongunadu College of Engineering and Technology'),
(15, 'Trichy', 'Kurunji College of Engineering and Technology'),
(16, 'Trichy', 'Shri Angalamman College of Engineering and Technology'),
(17, 'Vallam', 'Periyar Maniammai'),
(18, 'Thanjavur', 'SASTRA'),
(19, 'Chennai', 'IIT Madras'),
(20, 'Chennai', '(Anna Univ) College of Engg, Guindy'),
(21, 'Vellore', 'VIT'),
(22, 'Chennai', 'VIT'),
(23, 'Chennai', 'Madras Institute of technology (MIT)'),
(24, 'Chennai', 'SSN College of Engg'),
(25, 'Chennai', 'Rajalakshmi Engineering College'),
(26, 'Chennai', 'Sri Sai Ram Engineering College'),
(27, 'Chennai', 'Shri Venkateshwara Engg. College'),
(28, 'Chennai', 'SRM'),
(29, 'Chennai', 'Tamilnadu College of Engineering'),
(30, 'Chennai', 'Sathyabama University'),
(31, 'Chennai', 'VEL Tech Technical University'),
(32, 'Chennai', 'Panimalar Engineering College'),
(33, 'Chennai', 'Jaya Engineering College'),
(34, 'Chennai', 'Velammal Engineering College'),
(35, 'Chennai', 'St Joseph''s College of Engineering'),
(36, 'Chennai', 'RMK Engineering College'),
(37, 'Chennai', 'RMD Engineering College'),
(38, 'Chennai', 'Bhajrang Engineering College'),
(39, 'Chennai', 'Prathyusha Institute of Technolgy'),
(40, 'Chennai', 'Easwari College of Engineering'),
(41, 'Chennai', 'St.Peters''s College of Engineering'),
(42, 'Chennai', 'Hindustan University'),
(43, 'Chennai', 'Meenakshi Sunderrajan Col of Engg'),
(44, 'Kancheepuram', 'Arulmigu Meenakshi College of Engineering'),
(45, 'Sriperumbdur', 'Sri Venkateshwara College of Engineering and Technology'),
(46, 'Madurai', 'Thiyagarajar college of engineering'),
(47, 'Salem', 'Narasu''s Sarathy Institute of Technology'),
(48, 'Salem', 'Sona College of Technology'),
(49, 'Salem', 'AVS Engineering College'),
(50, 'Salem', 'Muthayammal College of Engineering'),
(51, 'Salem', 'Government College of Engineering'),
(52, 'Salem', 'Annapoorna Engineering College'),
(53, 'Salem', 'Vinayaga Mission''s Kirupananda Variyar  Engg College'),
(54, 'Madurai', 'KLN college of engineering'),
(55, 'Madurai', 'Latha Mathavan engineering college'),
(56, 'Madurai', 'SACS -M.A.V.M.M.Engineering College'),
(57, 'Madurai', 'Velammal College of Engineering and Technology'),
(58, 'Madurai', 'Vickram College of Engineering'),
(59, 'Madurai', 'P.T.R.College of Engineering and Technology'),
(60, 'Madurai', 'Sethu Institute of Technology'),
(61, 'Madurai', 'MEPCO'),
(62, 'Madurai', 'Kalasalingam University'),
(63, 'Madurai', 'KLNCE'),
(64, 'Coimbatore', 'Karunya University'),
(65, 'Erode', 'IRTT'),
(66, 'Erode', 'Kongu'),
(67, 'Coimbatore', 'Kumaraguru'),
(68, 'Coimbatore', 'GCT'),
(69, 'Coimbatore', 'PSG TECH'),
(70, 'Karaikal', 'NIT-Puduchery'),
(71, 'Coimbatore', 'Coimbatore Institute of Technology'),
(72, 'Coimbatore', 'Amrita University'),
(73, 'Bangalore', ' '),
(74, 'Hyderabad', ' '),
(75, 'Vishakhapatnam', ' '),
(76, 'Surathkal', ' '),
(77, 'Thiruvananthapuram', ' '),
(78, 'Calicut', ' '),
(79, 'Vijayawada', ' '),
(80, 'Delhi', ' '),
(81, 'Mumbai', ''),
(82, 'Warangal', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
